<?php
    // Проверяем, авторизован ли пользователь
    session_start();
    if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
        // Если не авторизован, перенаправляем на страницу авторизации
        header("location: auth_page.php");
        exit;
    }
    // Обработчик нажатия на кнопку "Выйти"
    if (isset($_POST['logout'])) {
        // Разрываем сеанс
        session_unset();
        session_destroy();
        // Перенаправляем на страницу авторизации
        header("location: auth_page.php");
        exit;
    }
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="0">

    <link rel="stylesheet" href="/style/admin_panel.css">
    <link rel="stylesheet" href="/style/global_style.css">
    <!-- <link rel="stylesheet" href="/style/modal_window.css"> -->
    <link rel="stylesheet" href="/style/mobile_styles.css">
    <script src="/scripts/nav_toggle.js"></script>



    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/noUiSlider/14.6.3/nouislider.min.css">


    <!-- <script src="/scripts/tabs.js"></script> -->
    <script>
            function redirectToIndex() {
                window.location.href = 'index.php';
            }

            // Переместим определение функции submitForm() выше использования
            function submitForm() {
                document.getElementById("logoutForm").submit();
            }
        </script>

        <!-- ВКЛАДКИ -->
        <script>
        // Дождемся полной загрузки всего HTML-документа, чтобы можно было внести изменения
        document.addEventListener("DOMContentLoaded", function() {
            // Восстанавливаем выбранную вкладку из localStorage или по умолчанию открываем 'zakaz'
            var savedTabId = localStorage.getItem('selectedTab') || 'zakaz';
            changeTab(savedTabId);

            // Добавляем обработчики событий для свайпов
            addSwipeListeners();
        });

        // Функция для изменения отображения вкладок и кнопок
        function changeTab(tabId) {
            // Получаем все элементы с классом 'tab-content' и скрываем их
            var allTabs = document.getElementsByClassName('tab-content');
            for (var i = 0; i < allTabs.length; i++) {
                allTabs[i].style.display = 'none';
            }

            // Отображаем выбранную вкладку на основе ее идентификатора
            var selectedTab = document.getElementById(tabId);
            if (selectedTab) {
                selectedTab.style.display = 'block';
            }

            // Удаляем класс 'darkened' у всех кнопок в навигации
            var allButtons = document.querySelectorAll('nav button');
            for (var i = 0; i < allButtons.length; i++) {
                allButtons[i].classList.remove('darkened');
            }

            // Добавляем класс 'darkened' активной кнопке в навигации на основе идентификатора вкладки
            var activeButton = document.querySelector('nav button[data-tab="' + tabId + '"]');
            if (activeButton) {
                activeButton.classList.add('darkened');
            }

            // Сохраняем идентификатор выбранной вкладки в localStorage
            localStorage.setItem('selectedTab', tabId);
        }
    </script>


    <link rel="icon" href="/resources/logo.png" type="image/x-icon">

    <title>Админ панель</title>
</head>
<body>

    <div class="menu-toggle"><img src="/resources/sidebar-bottom-svgrepo-com.svg" alt=""></div>

    <nav>
        <ul>
            <img src="/resources/logo.png" alt="Ошибка подгрузки">
            <li><button onclick="redirectToIndex()">Сайт</button></li>
            <li><button class="zakaz" data-tab="zakaz" onclick="changeTab('zakaz')">Заказы</button></li>
            <li><button class="tovar" data-tab="tovar" onclick="changeTab('tovar')">Товары</button></li>
        
            <!-- Завершить сеанс -->
            <li>
                <!-- Используем функцию submitForm() -->
                <button onclick="submitForm()">Завершить сеанс</button>
                <form id="logoutForm" method="post" action="">
                    <input type="hidden" name="logout">
                </form>
            </li>

        </ul>
    </nav>

    <div id="zakaz" class="tab-content">
        <div class="main_con">
            <div class="sub_con">
                <!-- Поисковая форма по ID клиента -->
                <form method="post" action="">
                    <label for="buyerId">Введите ID клиента:</label>
                    <input type="text" id="buyerId" name="buyerId">
                    <input type="submit" value="Поиск">
                    <button type="submit" name="reset">Сбросить</button>
                </form>

                <!-- вывод таблиц бд -->
                <?php
                    // Подключение к базе данных
                    $servername = "localhost";
                    $username = "m1inc3re_data";
                    $password = "&fX8mO62";
                    $database = "m1inc3re_data";

                    // Установка соединения с базой данных
                    $conn = new mysqli($servername, $username, $password, $database);

                    // Проверка соединения
                    if ($conn->connect_error) {
                        die("Ошибка подключения к базе данных: " . $conn->connect_error);
                    }

                    // Инициализация переменной для хранения ID клиента
                    $buyerId = null;

                    // Проверка отправки формы
                    if ($_SERVER["REQUEST_METHOD"] == "POST") {
                        if (isset($_POST['reset'])) {
                            $buyerId = null;
                        } else if (isset($_POST['buyerId']) && $_POST['buyerId'] !== '') {
                            $buyerId = intval($_POST['buyerId']);
                        }
                    }

                    // Выполнение запроса для таблицы BuyerData
                    if ($buyerId !== null) {
                        $sql_buyer_data = "SELECT * FROM BuyerData WHERE id = $buyerId ORDER BY created_at DESC";
                    } else {
                        $sql_buyer_data = "SELECT * FROM BuyerData ORDER BY created_at DESC";
                    }
                    $result_buyer_data = $conn->query($sql_buyer_data);

                    // Выполнение запроса для таблицы CartItems
                    if ($buyerId !== null) {
                        $sql_cart_items = "SELECT * FROM CartItems WHERE buyerId = $buyerId ORDER BY created_at DESC";
                    } else {
                        $sql_cart_items = "SELECT * FROM CartItems ORDER BY created_at DESC";
                    }
                    $result_cart_items = $conn->query($sql_cart_items);

                    // Проверка наличия результатов и вывод данных из таблицы BuyerData
                    if ($result_buyer_data->num_rows > 0) {
                        echo "<div class='table-container'>";
                        echo "<h2>Таблица BuyerData</h2>";
                        echo "<table>";
                        echo "<tr><th>ID</th><th>Имя</th><th>Email</th><th>Телефон</th><th>Сообщение</th><th>Дата создания</th></tr>";
                        while($row = $result_buyer_data->fetch_assoc()) {
                            echo "<tr><td>".$row["id"]."</td><td>".$row["name"]."</td><td>".$row["email"]."</td><td>".$row["phone"]."</td><td>".$row["msg"]."</td><td>".$row["created_at"]."</td></tr>";
                        }
                        echo "</table>";
                        echo "</div>";
                    } else {
                        echo "<p>Нет данных в таблице BuyerData</p>";
                    }

                    // Проверка наличия результатов и вывод данных из таблицы CartItems
                    if ($result_cart_items->num_rows > 0) {
                        echo "<div class='table-container'>";
                        echo "<h2>Таблица CartItems</h2>";
                        echo "<table>";
                        echo "<tr><th>ID</th><th>Название товара</th><th>Количество</th><th>Единица измерения</th><th>ID покупателя</th><th>Дата создания</th></tr>";
                        while($row = $result_cart_items->fetch_assoc()) {
                            echo "<tr><td>".$row["id"]."</td><td>".$row["productName"]."</td><td>".$row["quantity"]."</td><td>".$row["unit"]."</td><td>".$row["buyerId"]."</td><td>".$row["created_at"]."</td></tr>";
                        }
                        echo "</table>";
                        echo "</div>";
                    } else {
                        echo "<p>Нет данных в таблице CartItems</p>";
                    }

                    // Закрытие соединения с базой данных
                    $conn->close();
                ?>

            
            
            </div>
        </div>
    </div> 
    
    <div id="tovar" class="tab-content">
        <div class="split">
            <div class="add_product">
                <form id="productForm" onsubmit="event.preventDefault(); addProduct();" method="post">                    <label for="product_code">ГОСТ:</label><br>
                    <input type="text" id="product_code" name="product_code"><br><br>

                    <label for="category_id">Категория:</label><br>
                    <select id="category_id" name="category_id">
                        <?php
                        // Подключение к базе данных
                        $servername = "localhost";
                        $username = "m1inc3re_data";
                        $password = "&fX8mO62";
                        $database = "m1inc3re_data";

                        $conn = new mysqli($servername, $username, $password, $database);
                        if ($conn->connect_error) {
                            die("Connection failed: " . $conn->connect_error);
                        }

                        // Получение списка категорий из базы данных
                        $sql = "SELECT id, name FROM categories";
                        $result = $conn->query($sql);

                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                echo "<option value='" . $row["id"] . "'>" . $row["name"] . "</option>";
                            }
                        }

                        $conn->close();
                        ?>
                    </select><br><br>

                    <label for="diameter">Диаметр:</label><br>
                    <div id="diameterSlider"></div>
                    <input type="hidden" id="diameter" name="diameter"><br>

                    <label for="strengthClass">Класс прочности:</label><br>
                    <div id="strengthClassSlider"></div>
                    <input type="hidden" id="strengthClass" name="strength_class"><br>

                    <label for="threadPitch">Шаг резьбы:</label><br>
                    <div id="threadPitchSlider"></div>
                    <input type="hidden" id="threadPitch" name="thread_pitch"><br>


                    <label for="materials">Материал:</label><br>
                    <?php
                        // Подключение к базе данных
                        $conn = new mysqli($servername, $username, $password, $database);
                        if ($conn->connect_error) {
                            die("Connection failed: " . $conn->connect_error);
                        }

                        // Получение списка материалов из базы данных
                        $sql = "SELECT id, name FROM materials";
                        $result = $conn->query($sql);

                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                echo "<input type='checkbox' id='material_" . $row["id"] . "' name='materials[]' value='" . $row["id"] . "'>";
                                echo "<label for='material_" . $row["id"] . "'>" . $row["name"] . "</label><br>";
                            }
                        }

                        $conn->close();
                    ?>
                    <input type="submit" value="Добавить">
                </form>
            </div>
            <div class="bdtovar">
                <table>
                    <tr>
                        <th>ID</th>
                        <th>ГОСТ</th>
                        <th>Категория</th>
                        <th>Диаметр</th>
                        <th>Класс прочности</th>
                        <th>Шаг резьбы</th>
                        <th>Материалы</th>
                        <th>Действия</th>
                    </tr>
                    <?php
                    // Подключение к базе данных
                    $servername = "localhost";
                    $username = "m1inc3re_data";
                    $password = "&fX8mO62";
                    $database = "m1inc3re_data";

                    $conn = new mysqli($servername, $username, $password, $database);
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }

                    // SQL-запрос для получения списка товаров и связанных с ними данных
                    $sql = "
                        SELECT 
                            p.id, 
                            p.product_code, 
                            c.name AS category, 
                            p.diameter, 
                            p.strength_class, 
                            p.thread_pitch, 
                            GROUP_CONCAT(m.name SEPARATOR ', ') AS materials 
                        FROM 
                            products p 
                            LEFT JOIN categories c ON p.category_id = c.id 
                            LEFT JOIN product_materials pm ON p.id = pm.product_id 
                            LEFT JOIN materials m ON pm.material_id = m.id 
                        GROUP BY 
                            p.id
                        ORDER BY 
                            p.id DESC
                    ";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        // Выводим каждый товар в виде строки таблицы
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . $row["id"] . "</td>";
                            echo "<td>" . htmlspecialchars($row["product_code"]) . "</td>";
                            echo "<td>" . htmlspecialchars($row["category"]) . "</td>";
                            echo "<td>" . htmlspecialchars($row["diameter"]) . "</td>";
                            echo "<td>" . htmlspecialchars($row["strength_class"]) . "</td>";
                            echo "<td>" . htmlspecialchars($row["thread_pitch"]) . "</td>";
                            echo "<td>" . htmlspecialchars($row["materials"]) . "</td>";
                            // Добавляем кнопку "Удалить" с передачей ID товара в качестве параметра
                            echo "<td><button onclick='deleteProduct(" . $row["id"] . ")'>Удалить</button></td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='8'>Таблица пуста</td></tr>";
                    }

                    $conn->close();
                    ?>
                </table>
            </div>
        </div>
    </div>

    <!-- сбив при удалении -->
    <script>
        function deleteProduct(productId) {
            if (confirm("Вы уверены, что хотите удалить этот товар?")) {
                // Отправляем AJAX-запрос на удаление товара
                var xhr = new XMLHttpRequest();
                xhr.open("POST", "delete_product.php", true);
                xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                xhr.onreadystatechange = function() {
                    if (xhr.readyState == 4 && xhr.status == 200) {
                        // Проверяем, удаление прошло успешно или нет
                        if (xhr.responseText.trim() === "success") {
                            // Если успешно, обновляем страницу
                            location.reload();
                        } else {
                            // Если есть ошибка, выводим её в консоль
                            console.error(xhr.responseText);
                        }
                    }
                };
                // Отправляем запрос с ID товара
                xhr.send("id=" + productId);
            }
        }
    </script>

    <!-- сбив при добавлении позиции -->
    <script>
        function addProduct() {
            // Получение данных формы
            var formData = new FormData(document.getElementById("productForm"));

            // Отправка данных через AJAX
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "add_product.php", true);
            xhr.onload = function() {
                if (xhr.status === 200) {
                    // Вывод сообщения об успешном добавлении
                    // alert(xhr.responseText);
                    // Перезагрузка страницы после успешного добавления
                    location.reload();
                } else {
                    // Вывод сообщения об ошибке
                    alert("Ошибка при добавлении товара: " + xhr.responseText);
                }
            };
            xhr.send(formData);
        }
    </script>

    <!-- ползунки -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/noUiSlider/14.6.3/nouislider.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/wnumb/1.2.0/wNumb.min.js"></script>
    <script>
        // Функция для обновления скрытого поля с диапазоном значений
        function updateHiddenField(slider, hiddenField) {
            var values = slider.noUiSlider.get(); // Получаем текущие значения ползунка
            hiddenField.value = values.join(' - '); // Обновляем значение скрытого поля
        }

        // Создаем слайдеры для каждого поля
        var diameterSlider = document.getElementById('diameterSlider');
        var diameterRange = document.getElementById('diameter');
        noUiSlider.create(diameterSlider, {
            start: [1, 100],
            connect: true,
            range: {
                'min': 1,
                'max': 100
            },
            tooltips: [wNumb({decimals: 0}), wNumb({decimals: 0})], // Отображение цифровых значений
            format: wNumb({decimals: 0}) // Форматирование значений
        });
        diameterSlider.noUiSlider.on('update', function () {
            updateHiddenField(diameterSlider, diameterRange);
        });

        // Аналогично для других ползунков
        var strengthClassSlider = document.getElementById('strengthClassSlider');
        var strengthClassRange = document.getElementById('strengthClass');
        noUiSlider.create(strengthClassSlider, {
            start: [1, 100],
            connect: true,
            range: {
                'min': 1,
                'max': 100
            },
            tooltips: [wNumb({decimals: 0}), wNumb({decimals: 0})],
            format: wNumb({decimals: 0})
        });
        strengthClassSlider.noUiSlider.on('update', function () {
            updateHiddenField(strengthClassSlider, strengthClassRange);
        });

        var threadPitchSlider = document.getElementById('threadPitchSlider');
        var threadPitchRange = document.getElementById('threadPitch');
        noUiSlider.create(threadPitchSlider, {
            start: [1, 100],
            connect: true,
            range: {
                'min': 1,
                'max': 100
            },
            tooltips: [wNumb({decimals: 0}), wNumb({decimals: 0})],
            format: wNumb({decimals: 0})
        });
        threadPitchSlider.noUiSlider.on('update', function () {
            updateHiddenField(threadPitchSlider, threadPitchRange);
        });
    </script>

</body>
</html>
